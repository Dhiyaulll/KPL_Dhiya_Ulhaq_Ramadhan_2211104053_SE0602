class HaloGeneric {
    SapaUser(x) {
      console.log(`Halo user ${x}`);
    }
  }
  
  const halo = new HaloGeneric();
  
  halo.SapaUser("Dhiya");
  
  console.log("=== Code Execution Successful ===");